package com.dompetnih.app;

import android.Manifest;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Base64;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONException;

/** Jembatan native: baca notifikasi, daftar aplikasi, OCR struk (ML Kit), dan suara. */
@CapacitorPlugin(
    name = "Dompetnih",
    permissions = {@Permission(strings = {Manifest.permission.RECORD_AUDIO}, alias = "mic")}
)
public class DompetnihPlugin extends Plugin {
    private static DompetnihPlugin inst;
    private SpeechRecognizer sr;

    @Override
    public void load() {
        inst = this;
        RebindJob.schedule(getContext());
    }

    /** Setiap aplikasi dibuka lagi: pindai notifikasi yang terlewat lalu minta JS mengambil antrean. */
    @Override
    protected void handleOnResume() {
        NotifListener.scanActive(getContext());
        notifyListeners("notif", new JSObject());
    }

    @Override
    protected void handleOnDestroy() {
        killVoice();
    }

    /** Dipanggil service saat ada notifikasi baru; JS lalu mengambil antrean. */
    static void ping() {
        DompetnihPlugin p = inst;
        if (p != null) p.notifyListeners("notif", new JSObject());
    }

    // ---------- notifikasi ----------

    private boolean listenerEnabled() {
        String flat = Settings.Secure.getString(getContext().getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getContext().getPackageName());
    }

    @PluginMethod
    public void status(PluginCall call) {
        boolean ok = listenerEnabled();
        if (ok && Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationListenerService.requestRebind(new ComponentName(getContext(), NotifListener.class));
            } catch (Throwable ignored) {
            }
        }
        JSObject o = new JSObject();
        o.put("granted", ok);
        o.put("pending", NotifStore.count(getContext()));
        call.resolve(o);
    }

    @PluginMethod
    public void scan(PluginCall call) {
        JSObject o = new JSObject();
        o.put("found", NotifListener.scanActive(getContext()));
        o.put("pending", NotifStore.count(getContext()));
        call.resolve(o);
    }

    @PluginMethod
    public void batteryStatus(PluginCall call) {
        boolean ok = true;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                android.os.PowerManager pm = (android.os.PowerManager) getContext().getSystemService(android.content.Context.POWER_SERVICE);
                ok = pm != null && pm.isIgnoringBatteryOptimizations(getContext().getPackageName());
            }
        } catch (Throwable ignored) {
        }
        JSObject o = new JSObject();
        o.put("unrestricted", ok);
        call.resolve(o);
    }

    /** Minta sistem tidak membatasi baterai aplikasi ini; jika gagal, buka halaman info aplikasi. */
    @PluginMethod
    public void requestIgnoreBattery(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(android.net.Uri.parse("package:" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Throwable t) {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(android.net.Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Throwable ignored) {
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        try {
            Intent i = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("Tidak bisa membuka pengaturan akses notifikasi");
        }
    }

    @PluginMethod
    public void setConfig(PluginCall call) {
        Boolean en = call.getBoolean("enabled", false);
        Set<String> s = new HashSet<String>();
        JSArray a = call.getArray("apps");
        if (a != null) {
            try {
                for (int i = 0; i < a.length(); i++) s.add(a.getString(i));
            } catch (JSONException ignored) {
            }
        }
        NotifStore.config(getContext(), en != null && en, s);
        RebindJob.schedule(getContext());
        call.resolve();
    }

    @PluginMethod
    public void drain(PluginCall call) {
        JSObject o = new JSObject();
        o.put("items", NotifStore.drain(getContext()));
        call.resolve(o);
    }

    @PluginMethod
    public void getApps(final PluginCall call) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    PackageManager pm = getContext().getPackageManager();
                    Intent m = new Intent(Intent.ACTION_MAIN);
                    m.addCategory(Intent.CATEGORY_LAUNCHER);
                    List<ResolveInfo> l = pm.queryIntentActivities(m, 0);
                    final List<String[]> out = new ArrayList<String[]>();
                    Set<String> seen = new HashSet<String>();
                    for (ResolveInfo r : l) {
                        String pkg = r.activityInfo.packageName;
                        if (pkg.equals(getContext().getPackageName()) || !seen.add(pkg)) continue;
                        out.add(new String[] {String.valueOf(r.loadLabel(pm)), pkg});
                    }
                    Collections.sort(out, new Comparator<String[]>() {
                        @Override
                        public int compare(String[] x, String[] y) {
                            return x[0].compareToIgnoreCase(y[0]);
                        }
                    });
                    JSArray arr = new JSArray();
                    for (String[] a : out) {
                        JSObject o = new JSObject();
                        o.put("name", a[0]);
                        o.put("pkg", a[1]);
                        arr.put(o);
                    }
                    JSObject res = new JSObject();
                    res.put("apps", arr);
                    call.resolve(res);
                } catch (Throwable t) {
                    call.reject("Gagal membaca daftar aplikasi");
                }
            }
        }).start();
    }

    // ---------- OCR struk (ML Kit, offline) ----------

    @PluginMethod
    public void recognize(final PluginCall call) {
        String b64 = call.getString("image");
        if (b64 == null || b64.isEmpty()) {
            call.reject("Gambar kosong");
            return;
        }
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bmp == null) {
                call.reject("Gambar tidak bisa dibaca");
                return;
            }
            final TextRecognizer rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            rec.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener(t -> {
                    JSObject o = new JSObject();
                    o.put("text", rows(t));
                    call.resolve(o);
                    closeQuiet(rec);
                })
                .addOnFailureListener(e -> {
                    call.reject("Gagal membaca teks: " + e.getMessage());
                    closeQuiet(rec);
                });
        } catch (Throwable e) {
            call.reject("Gagal membaca gambar");
        }
    }

    private static void closeQuiet(TextRecognizer r) {
        try {
            r.close();
        } catch (Exception ignored) {
        }
    }

    /** Menyusun ulang baris struk: teks dengan tinggi sejajar digabung (nama barang + harga). */
    static String rows(Text t) {
        List<Text.Line> ls = new ArrayList<Text.Line>();
        for (Text.TextBlock b : t.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                if (l.getBoundingBox() != null) ls.add(l);
            }
        }
        Collections.sort(ls, new Comparator<Text.Line>() {
            @Override
            public int compare(Text.Line a, Text.Line b) {
                return a.getBoundingBox().centerY() - b.getBoundingBox().centerY();
            }
        });
        StringBuilder out = new StringBuilder();
        List<Text.Line> row = new ArrayList<Text.Line>();
        int cy = 0;
        int h = 0;
        for (Text.Line l : ls) {
            Rect r = l.getBoundingBox();
            if (row.isEmpty()) {
                row.add(l);
                cy = r.centerY();
                h = r.height();
            } else if (Math.abs(r.centerY() - cy) <= Math.max(h, r.height()) * 0.6) {
                row.add(l);
                cy = (cy * (row.size() - 1) + r.centerY()) / row.size();
                h = Math.max(h, r.height());
            } else {
                flush(out, row);
                row.add(l);
                cy = r.centerY();
                h = r.height();
            }
        }
        flush(out, row);
        return out.toString().trim();
    }

    private static void flush(StringBuilder out, List<Text.Line> row) {
        if (row.isEmpty()) return;
        Collections.sort(row, new Comparator<Text.Line>() {
            @Override
            public int compare(Text.Line a, Text.Line b) {
                return a.getBoundingBox().left - b.getBoundingBox().left;
            }
        });
        for (int i = 0; i < row.size(); i++) {
            if (i > 0) out.append("  ");
            out.append(row.get(i).getText());
        }
        out.append('\n');
        row.clear();
    }

    // ---------- suara (SpeechRecognizer bawaan Android) ----------

    @PluginMethod
    public void startVoice(PluginCall call) {
        if (getPermissionState("mic") != PermissionState.GRANTED) {
            requestPermissionForAlias("mic", call, "micDone");
            return;
        }
        beginVoice(call);
    }

    @PermissionCallback
    private void micDone(PluginCall call) {
        if (getPermissionState("mic") == PermissionState.GRANTED) beginVoice(call);
        else call.reject("Izin mikrofon ditolak. Aktifkan di Pengaturan HP > Aplikasi > Dompetnih > Izin.");
    }

    private void beginVoice(final PluginCall call) {
        final String lang = call.getString("lang", "id-ID");
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
                        call.reject("Layanan suara tidak tersedia. Pasang atau perbarui aplikasi Google.");
                        return;
                    }
                    killVoice();
                    sr = SpeechRecognizer.createSpeechRecognizer(getContext());
                    sr.setRecognitionListener(new RecognitionListener() {
                        @Override public void onReadyForSpeech(Bundle p) {}
                        @Override public void onBeginningOfSpeech() {}
                        @Override public void onRmsChanged(float v) {}
                        @Override public void onBufferReceived(byte[] b) {}
                        @Override public void onEndOfSpeech() {}
                        @Override public void onEvent(int i, Bundle b) {}

                        @Override
                        public void onPartialResults(Bundle b) {
                            emitText("partial", first(b));
                        }

                        @Override
                        public void onResults(Bundle b) {
                            emitText("final", first(b));
                            notifyListeners("end", new JSObject());
                            killVoice();
                        }

                        @Override
                        public void onError(int code) {
                            JSObject o = new JSObject();
                            o.put("code", code);
                            o.put("message", errText(code));
                            notifyListeners("error", o);
                            notifyListeners("end", new JSObject());
                            killVoice();
                        }
                    });
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getContext().getPackageName());
                    sr.startListening(i);
                    call.resolve();
                } catch (Throwable t) {
                    call.reject("Suara tidak bisa dimulai");
                }
            }
        });
    }

    @PluginMethod
    public void stopVoice(final PluginCall call) {
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (sr != null) sr.stopListening();
                } catch (Throwable ignored) {
                }
                call.resolve();
            }
        });
    }

    private void emitText(String ev, String text) {
        JSObject o = new JSObject();
        o.put("text", text);
        notifyListeners(ev, o);
    }

    private static String first(Bundle b) {
        ArrayList<String> l = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return l != null && !l.isEmpty() ? l.get(0) : "";
    }

    private static String errText(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_NO_MATCH: return "Suara tidak terbaca, coba lagi lebih jelas.";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "Tidak ada suara terdengar, ketuk mikrofon dan coba lagi.";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Izin mikrofon ditolak.";
            case SpeechRecognizer.ERROR_NETWORK:
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Pengenalan suara butuh internet di HP ini. Cek koneksi atau ketik perintahnya.";
            case SpeechRecognizer.ERROR_AUDIO: return "Mikrofon bermasalah, coba lagi.";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Pengenal suara sedang sibuk, coba lagi sebentar.";
            default: return "Suara tidak terbaca, coba lagi atau ketik.";
        }
    }

    private void killVoice() {
        if (sr != null) {
            try {
                sr.destroy();
            } catch (Throwable ignored) {
            }
            sr = null;
        }
    }
}
