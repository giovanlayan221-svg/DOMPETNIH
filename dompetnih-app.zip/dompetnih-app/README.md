# Dompetnih (aplikasi Android)

Aplikasi keuangan offline-first. Login dan sinkron lewat Firebase, dibungkus jadi APK dengan Capacitor, dibuild otomatis oleh GitHub Actions.

## Build APK lewat GitHub
1. Buat repository baru di GitHub.
2. Upload SEMUA isi folder ini, termasuk folder `.github`.
   Kalau `.github` tidak ikut: Add file > Create new file, ketik nama `.github/workflows/android.yml`, lalu tempel isi file dengan nama yang sama dari folder ini.
3. Buka tab **Actions**. Workflow **Build APK** jalan otomatis setiap ada upload (atau klik Run workflow).
4. Tunggu sekitar 5 sampai 10 menit sampai centang hijau.
5. Klik run tersebut, gulir ke **Artifacts**, unduh **dompetnih-apk**, ekstrak, lalu pasang `app-debug.apk` di HP (izinkan pasang dari sumber tidak dikenal).

## Isi folder
- `web/` : aplikasi (index.html, manifest, ikon). Bisa juga di-deploy ke Vercel sebagai web.
- `src/firebase-bundle.js` : Firebase dibundel ke dalam aplikasi.
- `resources/android/` : ikon aplikasi (launcher, bulat, adaptif) dan logo layar pembuka dari logo Dompetnih. Dipasang otomatis saat build.
- `capacitor.config.json` : nama dan id aplikasi (com.dompetnih.app).
- `firestore.rules` : aturan keamanan database, tempel di Firebase > Firestore > Rules.

## Fitur native di APK
- **Catat otomatis dari notifikasi** (e-wallet dan m-banking): aplikasi membaca notifikasi hanya dari aplikasi yang kamu pilih.
- **Pindai struk**: OCR offline Google ML Kit, hasilnya diisikan ke toko, total, tanggal, dan jam.
- **Catat dengan suara**: memakai pengenal suara bawaan Android (butuh layanan suara Google di HP).

## Mengaktifkan catat otomatis (sekali saja)
1. Buka aplikasi, pilih aplikasi e-wallet atau m-banking yang dipakai, lalu ketuk Mulai. Layar pengaturan akses notifikasi akan terbuka.
2. Aktifkan **Dompetnih** di daftar akses notifikasi.
3. Android 13 ke atas: kalau tombolnya abu-abu atau muncul "Pengaturan dibatasi", buka **Info aplikasi Dompetnih**, ketuk titik tiga di pojok kanan atas, pilih **Izinkan setelan terbatas**, lalu ulangi langkah 2.
4. Di Pengaturan HP, atur baterai Dompetnih ke **Tanpa batasan** (dan izinkan mulai otomatis di HP OPPO, Xiaomi, Vivo, dan sejenisnya) supaya pembaca notifikasi tidak dimatikan sistem.
5. Cek di menu Atur > **Notifikasi terakhir**: di sana terlihat setiap notifikasi yang masuk beserta statusnya (tercatat, bukan transaksi, dobel).

## Catatan
- Ini APK debug (untuk dipasang langsung). APK rilis bertanda tangan menyusul.
- Di APK, login Google disembunyikan dulu. Pakai Email/Password.
- Format notifikasi tiap aplikasi berbeda-beda. Kalau ada yang tidak terbaca, lihat daftar Notifikasi terakhir, lalu kirim tangkapan layarnya agar pembacanya disesuaikan.

## Jika layar kosong atau ada masalah
- Aplikasi sekarang menampilkan kotak merah di atas layar berisi pesan error. Kirim tangkapan layar kotak itu.
- Kalau muncul "Plugin native Dompetnih tidak terdaftar": APK yang terpasang belum membawa kode native, pasang ulang APK terbaru dari GitHub Actions.

## Play Protect
APK debug yang dipasang manual dan meminta akses notifikasi, kamera, dan mikrofon sering ditandai Play Protect. Ini wajar untuk APK di luar Play Store. Untuk pemakaian pribadi pilih "Tetap instal" atau matikan sementara pemindaian aplikasi. Jalur resmi: APK rilis bertanda tangan lalu diunggah ke Google Play Console (uji internal).
