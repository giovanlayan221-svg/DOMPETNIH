# Dompetnih (aplikasi Android)

Aplikasi keuangan offline-first. Login dan sinkron lewat Firebase, dibungkus jadi APK dengan Capacitor, dibuild otomatis oleh GitHub Actions.

## Build APK lewat GitHub
1. Buat repository baru di GitHub.
2. Upload SEMUA isi folder ini, termasuk folder `.github`.
   Kalau `.github` tidak ikut: Add file > Create new file, ketik nama `.github/workflows/android.yml`, lalu tempel isi file dengan nama yang sama dari folder ini.
3. Buka tab **Actions**. Workflow **Build APK** jalan otomatis setiap ada upload (atau klik Run workflow).
4. Tunggu sekitar 5 sampai 10 menit sampai centang hijau.
5. Klik run tersebut, gulir ke **Artifacts**, unduh **dompetnih-apk**, ekstrak, lalu pasang `app-debug.apk` di HP (izinkan pasang dari sumber tidak dikenal).

## Isi folder
- `web/` : aplikasi (index.html, manifest, ikon). Bisa juga di-deploy ke Vercel sebagai web.
- `src/firebase-bundle.js` : Firebase dibundel ke dalam aplikasi.
- `resources/android/` : ikon aplikasi (launcher, bulat, adaptif) dan logo layar pembuka dari logo Dompetnih. Dipasang otomatis saat build.
- `capacitor.config.json` : nama dan id aplikasi (com.dompetnih.app).
- `firestore.rules` : aturan keamanan database, tempel di Firebase > Firestore > Rules.

## Catatan
- Ini APK debug (untuk dipasang langsung). APK rilis bertanda tangan menyusul.
- Di APK, login Google disembunyikan dulu. Pakai Email/Password.
- Belum ada di APK: baca notifikasi otomatis, suara native, OCR native. Ini tahap berikutnya (plugin Android).
