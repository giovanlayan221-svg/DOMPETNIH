import { build } from 'esbuild';
import { cpSync, rmSync, mkdirSync } from 'node:fs';
rmSync('www', { recursive: true, force: true });
mkdirSync('www', { recursive: true });
cpSync('web', 'www', { recursive: true });
await build({ entryPoints: ['src/firebase-bundle.js'], bundle: true, minify: true, format: 'iife', outfile: 'www/firebase-bundle.js', target: ['chrome90'] });
console.log('web siap di folder www');
