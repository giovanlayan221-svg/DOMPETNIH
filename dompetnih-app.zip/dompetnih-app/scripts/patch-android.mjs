// Dipanggil setelah "cap add android": izin, ikon, layar pembuka, dan kode native
// (pembaca notifikasi, OCR struk ML Kit, suara).
import { readFileSync, writeFileSync, existsSync, readdirSync, cpSync, unlinkSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';

const MAIN = 'android/app/src/main';
const RES = join(MAIN, 'res');
const BG = '#0450E3';

// 1) AndroidManifest: izin, layanan pembaca notifikasi, izin melihat daftar aplikasi
const mp = join(MAIN, 'AndroidManifest.xml');
let m = readFileSync(mp, 'utf8');
const perms = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />'
].filter(x => !m.includes(x.match(/"([^"]+)"/)[1]));
if (perms.length) m = m.replace('</manifest>', '    ' + perms.join('\n    ') + '\n</manifest>');
if (!m.includes('.NotifListener')) {
  m = m.replace('</application>',
`        <service android:name=".NotifListener" android:exported="true" android:label="Dompetnih"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>
    </application>`);
}
if (!m.includes('<queries>')) {
  m = m.replace('</manifest>',
`    <queries>
        <intent>
            <action android:name="android.intent.action.MAIN" />
            <category android:name="android.intent.category.LAUNCHER" />
        </intent>
        <intent>
            <action android:name="android.speech.RecognitionService" />
        </intent>
    </queries>
</manifest>`);
}
writeFileSync(mp, m);
console.log('manifest diperbarui');

// 2) kode native Java (plugin, layanan notifikasi, MainActivity)
const jdir = join(MAIN, 'java/com/dompetnih/app');
mkdirSync(jdir, { recursive: true });
cpSync('native/java', jdir, { recursive: true, force: true });
console.log('kode native disalin ke', jdir);

// 3) dependensi ML Kit (OCR struk offline)
const gp = 'android/app/build.gradle';
let g = readFileSync(gp, 'utf8');
if (!g.includes('mlkit')) {
  g = g.replace(/dependencies\s*\{/, mm => mm + "\n    implementation 'com.google.mlkit:text-recognition:16.0.1'");
  writeFileSync(gp, g);
}
console.log('ML Kit', g.includes('mlkit') ? 'terpasang' : 'GAGAL dipasang');

// 4) ikon (launcher, bulat, adaptif) dan logo layar pembuka
if (existsSync('resources/android')) cpSync('resources/android', RES, { recursive: true, force: true });
mkdirSync(join(RES, 'values'), { recursive: true });
writeFileSync(join(RES, 'values/ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${BG}</color>\n</resources>\n`);

let removed = 0;
for (const d of readdirSync(RES)) {
  if (!d.startsWith('drawable')) continue;
  const f = join(RES, d, 'splash.png');
  if (existsSync(f)) { unlinkSync(f); removed++; }
}
mkdirSync(join(RES, 'drawable'), { recursive: true });
writeFileSync(join(RES, 'drawable/splash.xml'),
`<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item><shape android:shape="rectangle"><solid android:color="${BG}" /></shape></item>
    <item><bitmap android:gravity="center" android:src="@drawable/splash_logo" /></item>
</layer-list>
`);
console.log('ikon dan splash terpasang, splash lama dihapus:', removed);
