// Dipanggil setelah "cap add android": izin kamera/mikrofon, ikon aplikasi, dan layar pembuka.
import { readFileSync, writeFileSync, existsSync, readdirSync, cpSync, unlinkSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';

const MAIN = 'android/app/src/main';
const RES = join(MAIN, 'res');
const BG = '#0450E3';

// 1) izin
const mp = join(MAIN, 'AndroidManifest.xml');
let m = readFileSync(mp, 'utf8');
const add = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />'
].filter(x => !m.includes(x.match(/"([^"]+)"/)[1]));
if (add.length) m = m.replace('</manifest>', '    ' + add.join('\n    ') + '\n</manifest>');
writeFileSync(mp, m);
console.log('manifest diperbarui:', add.length, 'baris');

// 2) ikon (launcher, bulat, adaptif) dan logo layar pembuka
if (existsSync('resources/android')) cpSync('resources/android', RES, { recursive: true, force: true });
mkdirSync(join(RES, 'values'), { recursive: true });
writeFileSync(join(RES, 'values/ic_launcher_background.xml'),
  `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${BG}</color>\n</resources>\n`);

// 3) layar pembuka biru dengan logo di tengah (ganti splash bawaan Capacitor)
let removed = 0;
for (const d of readdirSync(RES)) {
  if (!d.startsWith('drawable')) continue;
  const f = join(RES, d, 'splash.png');
  if (existsSync(f)) { unlinkSync(f); removed++; }
}
mkdirSync(join(RES, 'drawable'), { recursive: true });
writeFileSync(join(RES, 'drawable/splash.xml'),
`<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item><shape android:shape="rectangle"><solid android:color="${BG}" /></shape></item>
    <item><bitmap android:gravity="center" android:src="@drawable/splash_logo" /></item>
</layer-list>
`);
console.log('ikon dan splash terpasang, splash lama dihapus:', removed);
