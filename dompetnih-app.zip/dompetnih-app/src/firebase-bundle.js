// Firebase dibundel ke dalam aplikasi supaya bisa dibuka offline sejak pertama kali.
import * as A from 'firebase/app';
import * as Au from 'firebase/auth';
import * as F from 'firebase/firestore';
window.__FB = { A, Au, F };
