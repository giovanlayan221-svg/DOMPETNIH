package com.dompetnih.app;

import android.app.Notification;
import android.content.Context;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Membaca notifikasi dari aplikasi yang diizinkan pengguna lalu menaruhnya di antrean. */
public class NotifListener extends NotificationListenerService {

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null) return;
            Context c = getApplicationContext();
            if (!NotifStore.enabled(c)) return;
            String pkg = sbn.getPackageName();
            if (pkg == null || pkg.equals(c.getPackageName())) return;
            if (!NotifStore.apps(c).contains(pkg)) return;
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null) return;
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            Bundle e = n.extras;
            String title = s(e.getCharSequence(Notification.EXTRA_TITLE));
            String text = s(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
            if (text.isEmpty()) text = s(e.getCharSequence(Notification.EXTRA_TEXT));
            if (title.isEmpty() && text.isEmpty()) return;
            NotifStore.add(c, pkg, title, text, sbn.getPostTime());
            DompetnihPlugin.ping();
        } catch (Throwable ignored) {
        }
    }

    private static String s(CharSequence x) {
        return x == null ? "" : x.toString().trim();
    }
}
