// Runtime @capacitor/core dibundel ke dalam web supaya Capacitor.registerPlugin tersedia.
// Tanpa ini, window.Capacitor dari bridge native tidak punya registerPlugin.
import { Capacitor, registerPlugin } from '@capacitor/core';
window.Capacitor = window.Capacitor || Capacitor;
if (typeof window.Capacitor.registerPlugin !== 'function') window.Capacitor.registerPlugin = registerPlugin;
