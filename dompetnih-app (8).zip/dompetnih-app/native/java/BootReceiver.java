package com.dompetnih.app;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.service.notification.NotificationListenerService;

/** Setelah HP menyala, jadwalkan ulang tugas dan sambungkan pembaca notifikasi. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        try {
            RebindJob.schedule(c);
            if (NotifStore.enabled(c) && Build.VERSION.SDK_INT >= 24) {
                NotificationListenerService.requestRebind(new ComponentName(c, NotifListener.class));
            }
        } catch (Throwable ignored) {
        }
    }
}
