package com.dompetnih.app;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Membaca notifikasi dari aplikasi yang diizinkan pengguna lalu menaruhnya di antrean. */
public class NotifListener extends NotificationListenerService {

    private static NotifListener inst;

    @Override
    public void onListenerConnected() {
        inst = this;
        RebindJob.schedule(getApplicationContext());
        // Ambil notifikasi yang masuk saat layanan sempat mati.
        scanActive(getApplicationContext());
    }

    @Override
    public void onListenerDisconnected() {
        inst = null;
        // Minta sistem menyambungkan lagi supaya pencatatan tidak berhenti.
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationListenerService.requestRebind(new ComponentName(this, NotifListener.class));
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (add(getApplicationContext(), sbn)) DompetnihPlugin.ping();
        } catch (Throwable ignored) {
        }
    }

    /** Cari notifikasi yang masih ada di bilah notifikasi dan belum pernah diantrekan. Mengembalikan jumlah yang baru. */
    static int scanActive(Context c) {
        int n = 0;
        try {
            NotifListener l = inst;
            if (l == null || !NotifStore.enabled(c)) return 0;
            StatusBarNotification[] act = l.getActiveNotifications();
            if (act == null) return 0;
            long since = NotifStore.lastTs(c);
            java.util.Arrays.sort(act, new java.util.Comparator<StatusBarNotification>() {
                @Override
                public int compare(StatusBarNotification a, StatusBarNotification b) {
                    return Long.compare(a.getPostTime(), b.getPostTime());
                }
            });
            for (StatusBarNotification s : act) {
                if (s.getPostTime() <= since) continue;
                if (add(c, s)) n++;
            }
        } catch (Throwable ignored) {
        }
        return n;
    }

    private static boolean add(Context c, StatusBarNotification sbn) {
        if (sbn == null) return false;
        if (!NotifStore.enabled(c)) return false;
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(c.getPackageName())) return false;
        if (!NotifStore.apps(c).contains(pkg)) return false;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return false;
        if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return false;
        Bundle e = n.extras;
        String title = s(e.getCharSequence(Notification.EXTRA_TITLE));
        String text = s(e.getCharSequence(Notification.EXTRA_BIG_TEXT));
        if (text.isEmpty()) text = s(e.getCharSequence(Notification.EXTRA_TEXT));
        if (title.isEmpty() && text.isEmpty()) return false;
        return NotifStore.add(c, pkg, title, text, sbn.getPostTime());
    }

    private static String s(CharSequence x) {
        return x == null ? "" : x.toString().trim();
    }
}
