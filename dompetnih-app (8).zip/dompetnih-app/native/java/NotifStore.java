package com.dompetnih.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/** Antrean notifikasi di penyimpanan HP. Tetap ada walau aplikasi sedang ditutup. */
final class NotifStore {
    private static final String P = "dompetnih_notif";

    private NotifStore() {}

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(P, Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) {
        return sp(c).getBoolean("enabled", false);
    }

    static Set<String> apps(Context c) {
        return new HashSet<String>(sp(c).getStringSet("apps", new HashSet<String>()));
    }

    static void config(Context c, boolean enabled, Set<String> apps) {
        SharedPreferences.Editor ed = sp(c).edit().putBoolean("enabled", enabled).putStringSet("apps", apps);
        // Titik awal pemindaian: notifikasi sebelum fitur dinyalakan tidak ikut dicatat.
        if (sp(c).getLong("lastTs", 0) == 0) ed.putLong("lastTs", System.currentTimeMillis());
        ed.commit();
    }

    static long lastTs(Context c) {
        return sp(c).getLong("lastTs", 0);
    }

    static synchronized boolean add(Context c, String pkg, String title, String text, long ts) {
        try {
            JSONArray q = new JSONArray(sp(c).getString("queue", "[]"));
            if (q.length() > 0) {
                JSONObject l = q.getJSONObject(q.length() - 1);
                if (l.optString("pkg").equals(pkg) && l.optString("title").equals(title)
                        && l.optString("text").equals(text) && Math.abs(ts - l.optLong("ts")) < 5000) {
                    return false; // notifikasi yang sama persis dalam 5 detik
                }
            }
            JSONObject o = new JSONObject();
            o.put("pkg", pkg);
            o.put("title", title);
            o.put("text", text);
            o.put("ts", ts);
            q.put(o);
            while (q.length() > 200) q.remove(0);
            sp(c).edit().putString("queue", q.toString()).putLong("lastTs", Math.max(ts, lastTs(c))).commit();
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    static synchronized JSONArray drain(Context c) {
        try {
            String s = sp(c).getString("queue", "[]");
            sp(c).edit().putString("queue", "[]").commit();
            return new JSONArray(s);
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized int count(Context c) {
        try {
            return new JSONArray(sp(c).getString("queue", "[]")).length();
        } catch (Exception e) {
            return 0;
        }
    }
}
