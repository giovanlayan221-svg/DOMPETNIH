package com.dompetnih.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.service.notification.NotificationListenerService;

/** Tugas berkala otomatis: menyambungkan lagi pembaca notifikasi dan memindai yang terlewat. */
public class RebindJob extends JobService {
    private static final int ID = 7101;

    @Override
    public boolean onStartJob(JobParameters p) {
        try {
            Context c = getApplicationContext();
            if (NotifStore.enabled(c)) {
                if (Build.VERSION.SDK_INT >= 24) {
                    NotificationListenerService.requestRebind(new ComponentName(c, NotifListener.class));
                }
                NotifListener.scanActive(c);
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters p) {
        return true;
    }

    static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            for (JobInfo j : js.getAllPendingJobs()) if (j.getId() == ID) return;
            JobInfo.Builder b = new JobInfo.Builder(ID, new ComponentName(c, RebindJob.class))
                    .setPeriodic(15 * 60 * 1000L)
                    .setPersisted(true);
            js.schedule(b.build());
        } catch (Throwable ignored) {
        }
    }
}
